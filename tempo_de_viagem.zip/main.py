from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/calcular_tempo_viagem', methods=['POST'])
def calcular_tempo_viagem():
    distancia = float(request.form['distancia'])
    velocidade = float(request.form['velocidade'])

    tempo_viagem = round(distancia / velocidade, 2)

    return render_template('index.html',tempo_viagem=tempo_viagem,distancia=distancia,velocidade=velocidade)


if __name__ == '__main__':
    app.run(debug=True)
