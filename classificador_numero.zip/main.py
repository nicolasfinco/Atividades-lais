from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analisar', methods=['POST'])
def analisar():
    numero = int(request.form['numero'])
    tipo = "par" if numero % 2 == 0 else "ímpar"
    sinal = "positivo" if numero >= 0 else "negativo"

    resultado = f"O número {numero} é {tipo} e {sinal}."
    return render_template('index.html', resultado=resultado)

if __name__ == '__main__':
    app.run(debug=True)